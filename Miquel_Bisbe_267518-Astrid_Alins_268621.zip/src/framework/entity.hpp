//
//  entity.hpp
//  ComputerGraphics
////
////  Created by Miquel Bisbe Armengol on 26/1/24.
////
//
//#pragma once
//
//#include "main/includes.h"
//#include <map>
//#include <string>
//
//
//#include <stdio.h>
//
//#endif /* entity_hpp */
//
//class entity
//{
//    
//    
//};
